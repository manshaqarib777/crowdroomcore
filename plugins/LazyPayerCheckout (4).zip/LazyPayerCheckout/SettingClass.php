<?php
namespace Plugins\LazyPayerCheckout;

use Modules\Core\Abstracts\BaseSettingsClass;

class SettingClass extends BaseSettingsClass
{
    public static function getSettingPages()
    {
        return [];
    }
}
