@extends('layouts.user')
@section('head')

@endsection
@section('content')
    @include('Car::frontend.manageCar.bookingReport.index')
@endsection
@section('footer')

@endsection
