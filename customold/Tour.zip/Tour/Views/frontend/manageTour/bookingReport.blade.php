@extends('layouts.user')
@section('head')

@endsection
@section('content')
    @include('Tour::frontend.manageTour.bookingReport.index')
@endsection
@section('footer')

@endsection