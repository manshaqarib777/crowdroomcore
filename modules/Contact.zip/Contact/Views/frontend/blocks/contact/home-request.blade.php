{{-- all-new-update --}}
<div class="bravo-contact-block">
    <div class="container">
        <div class="row section">
            <div class="col-md-12 col-lg-5">
                <div role="form" class="form_wrapper" lang="en-US" dir="ltr">
                    <form method="post" action="{{ route("home_request.store") }}"  class="bravo-contact-block-form">
                        {{csrf_field()}}
                        <div style="display: none;">
                            <input type="hidden" name="g-recaptcha-response" value="">
                        </div>
                        <div class="contact-form">
                            <div class="contact-header">
                                <h1>{{ setting_item_with_lang("page_contact_title") }}</h1>
                                <h2>{{ setting_item_with_lang("page_contact_sub_title") }}</h2>
                            </div>
                            @include('admin.message')
                            <div class="contact-form">
                                <div class="form-group">
                                    <input type="text" placeholder=" {{ __('Name') }} " name="name" value="{{auth()->user()->name ?? ''}}" class="form-control" {{auth()->check() ? 'readonly':''}}>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="{{ __('Email') }}" name="email" value="{{auth()->user()->email ?? ''}}" class="form-control" {{auth()->check() ? 'readonly':''}}>
                                </div>
                                <div class="form-group">
                                    <input type="text" placeholder="{{ __('Phone') }}" name="phone" class="form-control" value="{{auth()->user()->phone ?? ''}}" {{auth()->check() ? 'readonly':''}}>
                                </div>
                                @guest
                                    <div class="form-group">
                                        <input type="password" placeholder="{{__("Your Password")}}" class="form-control" name="password">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" placeholder="{{__("Your Confirm Password")}}" class="form-control" name="password_confirmation">
                                    </div>
                                @endguest
                                <div class="form-group">
                                    <input type="date" placeholder="{{ __('Rent Start Date') }}" name="event_date" class="form-control">
                                </div>
                                {{-- <div class="form-group">
                                    <textarea name="event_type" cols="40" rows="10" class="form-control textarea" placeholder="{{ __('Event Type') }}"></textarea>
                                </div> --}}
                                <div class="form-group">
                                    <textarea name="message" cols="40" rows="10" class="form-control textarea" placeholder="{{ __('Message') }}"></textarea>
                                </div>
                                <div class="form-group">
                                    <select class="form-control select2" name="bedroom_id" required>
                                        <option value="" >Select Bedrooms</option>
                                        @foreach ($spaceBedrooms as $spaceBedroom)
                                        <option value="{{ $spaceBedroom->name }}" >{{ $spaceBedroom->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control select2" name="rental_terms[]" multiple="multiple" required>
                                        <option value="" disabled>Select Rental Terms</option>
                                        @foreach ($spaceRentalTerms as $spaceRentalTerm)
                                        <option value="{{ $spaceRentalTerm->name }}" >{{ $spaceRentalTerm->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control select2" name="preferred_area_id" required>
                                        <option value="" >Select Preferred Areas</option>
                                        @foreach ($spacePreferredAreas as $spacePreferredArea)
                                        <option value="{{ $spacePreferredArea->name }}" >{{ $spacePreferredArea->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control select2" name="budget_id" required>
                                        <option value="" >Select Budget</option>
                                        @foreach ($spaceBudgets as $spaceBudget)
                                        <option value="{{ $spaceBudget->name }}" >{{ $spaceBudget->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control select2" name="duration_id" required>
                                        <option value="" >Select Duration</option>
                                        @foreach ($spaceDurations as $spaceDuration)
                                        <option value="{{ $spaceDuration->name }}" >{{ $spaceDuration->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control select2" name="amenities[]" multiple="multiple" required>
                                        <option value="" disabled>Select Amenities</option>
                                        @foreach ($spaceAmenities as $spaceAmenitie)
                                        <option value="{{ $spaceAmenitie->name }}" >{{ $spaceAmenitie->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <select class="form-control select2" name="requirement[]" multiple="multiple" required>
                                        <option value="" disabled>Select Requirements</option>
                                        @foreach ($spaceRequirements as $spaceRequirement)
                                        <option value="{{ $spaceRequirement->name }}" >{{ $spaceRequirement->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    {{recaptcha_field('contact')}}
                                </div>
                                <p>
                                    <button class="submit btn btn-primary " type="submit">
                                        {{ __('SEND MESSAGE') }}
                                        <i class="fa fa-spinner fa-pulse fa-fw"></i>
                                    </button>
                                </p>
                            </div>
                        </div>
                        <div class="form-mess"></div>
                    </form>

                </div>
            </div>
            <div class="offset-lg-2 col-md-12 col-lg-5">
                <div class="contact-info">
                    <div class="info-bg">
                        @if($bg = get_file_url(setting_item("page_contact_image"),"full"))
                            <img src="{{$bg}}" class="img-responsive" alt="{{ setting_item_with_lang("page_contact_title") }}">
                        @endif
                    </div>
                    <div class="info-content">
                        <div class="sub">
                            <p>{!! setting_item_with_lang("page_contact_desc") !!}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
